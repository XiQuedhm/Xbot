def _notMain() :
    print("waht")
def main() :
    pass

